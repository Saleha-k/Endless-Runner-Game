#include <iostream>
#include <windows.h>
#include <conio.h>
#include <ctime>
#include <string>
#include <fstream>
using namespace std;

// Game constants and variables
const int ROWS = 20;
const int COLS = 30;
char map[ROWS][COLS];

int playerX = 14;
int playerY = ROWS - 3;
int score = 0;
int coins = 0;
int distanceTravelled = 0;
bool gameOver = false;
bool enemyActive = false;
int enemyX, enemyY;
int lives = 3;
int slideCounter = 0;
const int slideDuration = 5;

bool isJumping = false;
int jumpCounter = 0;
const int jumpHeight = 5;
bool isSliding = false;

void setColor(int color) {
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
}


// Moves the cursor to a specific coordinate on console (used for drawing)
void gotoxy(int x, int y) {
    COORD pos = { (SHORT)x, (SHORT)y };
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);
}

// Hides the blinking text cursor to make the game screen cleaner
void hideCursor() {
    HANDLE out = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO info;
    info.dwSize = 100;
    info.bVisible = FALSE;
    SetConsoleCursorInfo(out, &info);
}

// Sets up the initial game map with borders
void initMap() {
    for (int i = 0; i < ROWS; i++) {
        for (int j = 0; j < COLS; j++) {
            if (j == 0 || j == COLS - 1)
                map[i][j] = '|';  // side walls
            else
                map[i][j] = ' ';  // empty space
        }
    }
}

// Clears the player's previous position on the map
void clearPlayer() {
    for (int i = 0; i < 3; i++) {
        for (int j = -1; j <= 1; j++) {
            int y = playerY + i;
            int x = playerX + j;
            if (y >= 0 && y < ROWS && x > 0 && x < COLS - 1)
                map[y][x] = ' ';
        }
    }
}

// Draws the player character in either standing or sliding form
void drawPlayer() {
    // Head
    map[playerY][playerX] = 'O';

    // Arms
    map[playerY + 1][playerX - 1] = '/';
    map[playerY + 1][playerX] = '|';
    map[playerY + 1][playerX + 1] = '\\';

    // Body
    map[playerY + 2][playerX] = '|';
}


// Randomly spawns either obstacles (X) or coins ($) at the top row
void spawnObjects() {
    int r = rand() % 10;

    // Define spawnable X-columns (e.g., columns 4, 11, and 18)
    int spawnColumns[] = { 4, 11, 20 };

    // Pick a random column from the 3 available
    int x = spawnColumns[rand() % 3];

    int y = 0; // Always spawn at top row

    // Use probability to decide object type
    if (r < 3)
        map[y][x] = 'X';  // 30% chance for obstacle
    else if (r < 6)
        map[y][x] = '$';  // 30% chance for coin
}

// Scrolls the map downward, simulating forward movement
void scrollMap() {
    for (int i = ROWS - 1; i > 0; i--) {
        for (int j = 1; j < COLS - 1; j++) {
            map[i][j] = map[i - 1][j];
        }
    }

    // Clear the top row and spawn new objects
    for (int j = 1; j < COLS - 1; j++) {
        map[0][j] = ' ';
    }
    spawnObjects();

    // Track distance and activate enemy after a certain point
    distanceTravelled += 10;
    if (distanceTravelled >= 2000 && !enemyActive) {
        enemyActive = true;
        enemyX = 1;
        enemyY = 1;
    }
}
void handleMovement() {
    // Handle keyboard input
    if (_kbhit()) {
        int ch = _getch();
        if (ch == 224) { // Arrow key prefix
            ch = _getch(); // Get actual arrow key
            switch (ch) {
            case 75: if (playerX > 2) playerX--; break; // Left
            case 77: if (playerX < COLS - 3) playerX++; break; // Right
            case 72: // Up - Jump
                if (!isJumping && !isSliding && playerY == ROWS - 3) {
                    isJumping = true;
                    jumpCounter = jumpHeight;
                }
                break;
            case 80: // Down - Slide
                if (!isJumping && !isSliding && playerY == ROWS - 3) {
                    isSliding = true;
                    playerY = ROWS - 2;
                    slideCounter = slideDuration;
                }
                break;
            }
        }
    }

    // Handle jumping animation
    if (isJumping) {
        if (jumpCounter > 0) {
            if (playerY > 0) playerY--;
            jumpCounter--;
        }
        else {
            if (playerY < ROWS - 3)
                playerY++;
            else
                isJumping = false;
        }
    }

    // Handle sliding duration and reset
    if (isSliding) {
        if (slideCounter > 0) {
            slideCounter--;
        }
        else {
            isSliding = false;
            playerY = ROWS - 3;
        }
    }
}

// Makes enemy follow player's position and checks collision
void moveEnemy() {
    if (!enemyActive) return;

    // Move enemy toward player vertically
    if (enemyY < playerY) enemyY++;
    else if (enemyY > playerY) enemyY--;

    // Move enemy toward player horizontally
    if (enemyX < playerX) enemyX++;
    else if (enemyX > playerX) enemyX--;

    // Display enemy on map
    if (enemyY >= 0 && enemyY < ROWS && enemyX > 0 && enemyX < COLS - 1) {
        map[enemyY][enemyX] = 'E';
    }

    // Check collision only if player is not jumping or sliding
    if (!isJumping && !isSliding && abs(enemyX - playerX) <= 1 && abs(enemyY - playerY) <= 1) {
        lives--;
        if (lives <= 0) {
            gameOver = true;
        }
        // Reset enemy position to avoid repeated collisions
        enemyX = 1;
        enemyY = 1;
    }
}

// Checks for collisions with coins and obstacles
void checkCollision() {
    // Check player collision in standing state
    for (int i = 0; i < 3; i++) {
        for (int j = -1; j <= 1; j++) {
            int y = playerY + i;
            int x = playerX + j;

            if (y >= 0 && y < ROWS && x > 0 && x < COLS - 1) {
                if (map[y][x] == '$') {
                    score += 50;
                    coins++;
                    map[y][x] = ' ';
                }
                else if (map[y][x] == 'X') {
                    if (!isJumping && !isSliding) {
                        lives--;
                        map[y][x] = ' ';
                        if (lives <= 0) {
                            gameOver = true;
                        }
                    }
                }
            }
        }
    }

    // Special collision check for sliding state (uses lower body hitbox)
    if (isSliding) {
        int y = playerY + 2;
        int x = playerX;
        if (y < ROWS && x > 0 && x < COLS - 1) {
            if (map[y][x] == '$') {
                score += 50;
                coins++;
                map[y][x] = ' ';
            }
            else if (map[y][x] == 'X') {
                lives--;
                map[y][x] = ' ';
                if (lives <= 0) {
                    gameOver = true;
                }
            }
        }
    }
}

// Draws the game map and HUD (lives, score, coins, distance)
void drawMap() {
    gotoxy(0, 0);

    // Display lives with color
    cout << "Lives: ";
    for (int i = 0; i < lives; i++) {
        setColor(12); // Red for lives
        cout << '*';
    }
    setColor(7); // Reset to white
    cout << "   Coins: ";
    setColor(14); // Yellow for coins
    cout << coins << endl;
    setColor(7); // Reset color

    // Draw the game map with colors
    for (int i = 0; i < ROWS; i++) {
        for (int j = 0; j < COLS; j++) {
            char c = map[i][j];

            if (c == '$') setColor(6);       // Yellow for coins
            else if (c == 'X') setColor(9);
            else if (c == 'E') setColor(4);   // Dark red for enemy
            else if (c == '|') setColor(13);  // Purple for borders 
            else setColor(7);                 // Default white for other characters

            cout << c;
        }
        cout << endl;
    }

    // Display score and distance
    setColor(11); // Light aqua for score info
    cout << "Score: " << score << "   Distance: " << distanceTravelled << "m" << endl;

    setColor(7); // Reset color to default
}


// Gets player name at the start
string getPlayerName() {
    string name;
    cout << "Enter your name: ";
    getline(cin, name);
    return name;
}

// Saves player name to a file
void savePlayerName(const string& name) {
    ofstream playerFile("player_data.txt", ios::app);
    if (playerFile.is_open()) {
        playerFile << "Player Name: " << name << endl;
        playerFile.close();
    }
}

// Saves player score to highscores file
void saveScore(const string& name, int score) {
    ofstream scoreFile("highscores.txt", ios::app);
    if (scoreFile.is_open()) {
        scoreFile << name << " - " << score << endl;
        scoreFile.close();
    }
}
// Displays high scores from file
void showHighScores() {
    system("cls");
    ifstream file("highscores.txt");
    string line;
    cout << "\nHigh Scores:\n----------------------\n";
    while (getline(file, line)) {
        cout << line << endl;
    }
    file.close();
    cout << "\nPress Enter to return to the main menu...";
    cin.ignore();
    cin.get();
}
// Displays the main menu options
void displayMenu() {
    system("cls"); // Clear the console
    setColor(10);
    cout << "\n  ENDLESS RUNNER GAME    \n";
    setColor(7);
    for (int i = 0; i < 20; i++) cout << "=";
    setColor(13);
    cout << "\n1. Start Game\n2. Instructions\n3. High Scores\n4. Quit\n";
    setColor(7);
    for (int i = 0; i < 20; i++) cout << "=";
    cout << endl;
}
// Shows instructions to the player
void displayInstruction() {
    system("cls"); // Clear the console

    for (int i = 0; i < 30; i++) cout << "=";
    cout << endl;
    setColor(12);
    cout << "INSTRUCTIONS\n";
    setColor(7);
    for (int i = 0; i < 30; i++) cout << "=";
    cout << endl;
    setColor(11);
    cout << "1. Use left and right arrow keys to move.\n";
    cout << "2. Press Up Arrow to jump.\n";
    cout << "3. Press Down Arrow to slide.\n";
    cout << "4. Avoid hitting 'X' and collect '$' to score points.\n";
    cout << "5. Each coin gives you 50 points.\n";
    cout << "6. You have 3 lives. Hitting obstacles reduces lives.\n";
    cout << "7. Press Enter to return to the menu...\n";
    setColor(7);
    cin.ignore(); // Clear buffer
    cin.get();    // Wait for user input
}
int main() {
    srand((unsigned)time(0)); // Seed for randomness
    hideCursor();             // Hide the console cursor
    while (true) {
        displayMenu(); // Show main menu
        int choice;
        cout << "Select an option (1-4): ";
        cin >> choice;
        cin.ignore(); // Clear newline from input buffer
        if (choice == 1) {
            // Start Game
            string playerName = getPlayerName(); // Ask player name
            savePlayerName(playerName);          // Save name to file
            // Reset game variables
            initMap();
            score = 0;
            coins = 0;
            distanceTravelled = 0;
            lives = 3;
            gameOver = false;
            playerX = 14;
            playerY = ROWS - 3;
            isJumping = false;
            isSliding = false;
            jumpCounter = 0;
            enemyActive = false;
            // Main game loop
            while (!gameOver) {
                clearPlayer();      // Remove previous player position
                handleMovement();   // Handle key inputs and actions
                scrollMap();        // Move the map for infinite runner effect
                checkCollision();   // Check for coins and obstacles
                moveEnemy();        // Move enemy toward player
                drawPlayer();       // Draw updated player position
                drawMap();          // Draw the current game map
                Sleep(100);         // Control game speed
            }
            // Game Over Screen
            system("cls");
            setColor(10);
            cout << "\n============= GAME OVER =============\n";
            setColor(7);
            cout << " Player Name       : "; setColor(9); cout << playerName << endl; setColor(7);
            cout << " Final Score       : "; setColor(8); cout << score << endl; setColor(7);
            cout << " Coins Collected   : "; setColor(14); cout << coins << endl; setColor(7);
            cout << " Distance Travelled: "; setColor(13); cout << distanceTravelled << "m" << endl;
            setColor(10); cout << "=====================================\n";
            saveScore(playerName, score); // Save final score to file
            setColor(7);

            cout << "\nPress any key to return to the main menu...";
            _getch(); // Wait for key press
        }
        else if (choice == 2) {
            displayInstruction(); // Show instructions
        }
        else if (choice == 3) {
            showHighScores();     // Display saved scores
        }
        else if (choice == 4) {
            break; // Exit the loop and end program
        }
    }
    system("pause"); // Pause before exiting
    return 0;
}
